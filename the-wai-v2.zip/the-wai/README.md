# The wAI — AI Prompt OS v0.2.0

> ai사용이 막막할때, ai로 무엇을 하고 싶은지 알려주세요

---

## 아키텍처

```
사용자 브라우저
    ↓  POST /api/ai-system  { goal, answers, error }
Next.js API Route (Vercel 서버)
    ↓  GEMINI_API_KEY (환경변수 — 절대 클라이언트에 노출 안 됨)
Google Gemini 1.5 Flash  ← 유일한 의사결정 엔진
    ↓  form | roadmap | error_solution
사용자 화면
```

**보안 원칙**
- API 키는 서버 환경변수에만 존재
- 클라이언트 소스코드에 키 없음
- 네트워크 탭에서도 키 보이지 않음

---

## 로컬 개발

```bash
# 1. 의존성 설치
npm install

# 2. 환경변수 설정
cp .env.example .env.local
# .env.local 파일을 열어 실제 Gemini 키 입력

# 3. 개발 서버 실행
npm run dev
# → http://localhost:3000
```

---

## 테스트

```bash
# 전체 테스트 실행
npm test

# CI 모드 (커버리지 포함)
npm run test:ci

# 린트
npm run lint
```

---

## Vercel 배포

### 1. GitHub에 올리기

```bash
git init
git add .
git commit -m "init: The wAI v0.2.0"
git remote add origin https://github.com/YOUR_ID/the-wai.git
git push -u origin main
```

### 2. Vercel 프로젝트 생성

1. [vercel.com](https://vercel.com) → **New Project**
2. GitHub 저장소 선택
3. Framework: **Next.js** (자동 감지)

### 3. 환경변수 설정 ⚠️ 핵심

Vercel 프로젝트 → **Settings → Environment Variables**:

| Name | Value | Environments |
|------|-------|-------------|
| `GEMINI_API_KEY` | `AIzaSy...` | Production, Preview, Development |

### 4. Deploy

**Deploy** 버튼 클릭 → 완료

### 5. 동작 확인 (헬스체크)

배포 후 아래 명령어로 API가 정상 동작하는지 확인:

```bash
curl -X POST https://your-app.vercel.app/api/ai-system \
  -H "Content-Type: application/json" \
  -d '{"goal":"test","answers":null,"error":null}'
# 응답: {"type":"form","questions":[...]} 또는 {"type":"roadmap",...}
```

---

## 환경변수

| 변수명 | 설명 | 필수 |
|--------|------|------|
| `GEMINI_API_KEY` | Google Gemini API 키 | ✅ |

키 발급: https://aistudio.google.com/app/apikey

---

## 오류 진단 가이드

| 증상 | 원인 | 해결 |
|------|------|------|
| `서버 설정 오류` | GEMINI_API_KEY 미설정 | Vercel 환경변수 확인 |
| `Gemini API 사용 한도 초과` | 429 quota | API 사용량 확인, 잠시 후 재시도 |
| `AI 응답 시간 초과` | 15s timeout | 네트워크 상태 확인, 재시도 |
| `모델을 찾을 수 없음` | 모델명 오류 | `gemini-1.5-flash` 모델 존재 확인 |

---

## CHANGELOG

### v0.2.0
- **[변경]** 백엔드 결정 엔진을 Gemini 단독으로 전환 (OpenAI 제거)
- **[변경]** API 응답 스키마 변경: `form.questions[]`, `roadmap.steps[].recommended_tools[]`
- **[추가]** 서버사이드 rate limiting (IP당 분당 20회)
- **[추가]** 구조화된 로깅 (timestamp, requestId, status — 키 미포함)
- **[추가]** 강화된 JSON 파싱 (malformed response 방어)
- **[추가]** 15초 요청 타임아웃
- **[추가]** 단위/통합 테스트
- **[추가]** GitHub Actions CI (lint → build → test)
- **[변경]** 프론트엔드 처리 단계 레이블: "Gemini 처리 중…"
- **[변경]** 상태머신: idle → loading → form | roadmap | error

### v0.1.0
- 초기 구현: OpenAI + Gemini 듀얼 AI
