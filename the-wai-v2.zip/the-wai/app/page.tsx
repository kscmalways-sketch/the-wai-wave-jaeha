'use client'

import { useState, useRef, useEffect } from 'react'
import type { AIResponse, RoadmapStep } from './api/ai-system/route'

// ─── State machine ─────────────────────────────────────────────────────────────
type Phase = 'idle' | 'loading' | 'form' | 'roadmap' | 'error'

const PROC_STEPS = ['분석 중…', 'Gemini 처리 중…', '프롬프트 생성 중…']

// ─── Inline styles ─────────────────────────────────────────────────────────────
const cs = (base: React.CSSProperties, extra?: React.CSSProperties): React.CSSProperties =>
  ({ ...base, ...extra })

const S = {
  app:       { minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0 24px 80px' } as React.CSSProperties,
  header:    { width: '100%', maxWidth: 680, padding: '64px 0 48px' } as React.CSSProperties,
  badge:     { display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: 'var(--accent-warm)', letterSpacing: '0.18em', textTransform: 'uppercase' as const, border: '1px solid rgba(200,184,154,0.25)', padding: '5px 10px', borderRadius: 2, marginBottom: 28 },
  title:     { fontFamily: "'DM Serif Display',serif", fontSize: 'clamp(22px,4vw,30px)', fontWeight: 400, lineHeight: 1.4, letterSpacing: '-0.01em' } as React.CSSProperties,
  card:      { width: '100%', maxWidth: 680, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 32 } as React.CSSProperties,
  cardLabel: { fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: 'var(--text-tertiary)', letterSpacing: '0.18em', textTransform: 'uppercase' as const, marginBottom: 16 },
  textarea:  { width: '100%', background: 'transparent', border: 'none', outline: 'none', color: 'var(--text-primary)', fontFamily: "'Noto Sans KR',sans-serif", fontSize: 17, fontWeight: 300, lineHeight: 1.6, resize: 'none' as const, caretColor: 'var(--accent-warm)', minHeight: 72 },
  footer:    { marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' } as React.CSSProperties,
  charCount: { fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: 'var(--text-tertiary)' } as React.CSSProperties,
  btn:       { display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 20px', background: 'var(--accent)', color: '#0a0a0b', fontFamily: "'Noto Sans KR',sans-serif", fontSize: 13, fontWeight: 500, border: 'none', borderRadius: 'var(--radius)', cursor: 'pointer' } as React.CSSProperties,
  btnGhost:  { background: 'transparent', color: 'var(--text-secondary)', border: '1px solid var(--border)', fontSize: 12 } as React.CSSProperties,
  secTitle:  { fontFamily: "'DM Serif Display',serif", fontSize: 20, fontWeight: 400, marginBottom: 6 } as React.CSSProperties,
  secDesc:   { fontSize: 13, color: 'var(--text-secondary)', marginBottom: 24, lineHeight: 1.6 } as React.CSSProperties,
  fieldWrap: { marginBottom: 20 } as React.CSSProperties,
  fieldLbl:  { display: 'block', fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 } as React.CSSProperties,
  fieldIn:   { width: '100%', background: 'transparent', border: 'none', borderBottom: '1px solid var(--border)', outline: 'none', color: 'var(--text-primary)', fontFamily: "'Noto Sans KR',sans-serif", fontSize: 15, fontWeight: 300, padding: '10px 0', caretColor: 'var(--accent-warm)' } as React.CSSProperties,
}

// ─── Loader ────────────────────────────────────────────────────────────────────
function Loader({ hidden }: { hidden: boolean }) {
  return (
    <div aria-hidden style={{ position: 'fixed', inset: 0, background: 'var(--bg)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 1000, opacity: hidden ? 0 : 1, visibility: hidden ? 'hidden' : 'visible', transition: 'opacity 0.8s ease, visibility 0.8s ease', pointerEvents: hidden ? 'none' : 'all' }}>
      <div style={{ fontFamily: "'DM Serif Display',serif", fontSize: 'clamp(80px,15vw,140px)', letterSpacing: '-0.04em', display: 'flex', alignItems: 'baseline', lineHeight: 1 }}>
        <span>A</span>
        <span style={{ position: 'relative', display: 'inline-block' }}>
          <span style={{ display: 'inline-block', animation: 'hideI 0.6s ease-in-out 1.2s both forwards' }}>i</span>
          <span style={{ position: 'absolute', left: 0, top: 0, color: 'var(--accent-warm)', animation: 'showExclaim 0.6s ease-in-out 1.2s both', opacity: 0 }}>!</span>
        </span>
      </div>
      <div style={{ marginTop: 28, fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: 'var(--text-tertiary)', letterSpacing: '0.2em', textTransform: 'uppercase', animation: 'fadeIn 0.6s ease 0.5s both' }}>made by Jh</div>
      <div style={{ marginTop: 48, width: 120, height: 1, background: 'var(--border)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', left: '-100%', top: 0, width: '100%', height: '100%', background: 'var(--accent-warm)', animation: 'loaderSlide 2s ease-in-out 0.3s both' }} />
      </div>
    </div>
  )
}

// ─── Processing ────────────────────────────────────────────────────────────────
function Processing({ activeIdx }: { activeIdx: number }) {
  return (
    <div role="status" aria-live="polite" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, padding: '48px 0', width: '100%', maxWidth: 680 }}>
      <div aria-hidden style={{ width: 44, height: 44, borderRadius: '50%', border: '1px solid var(--border-bright)', borderTopColor: 'var(--accent-warm)', animation: 'spin 1s linear infinite' }} />
      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: 'var(--text-secondary)', letterSpacing: '0.12em' }}>
        {PROC_STEPS[activeIdx] ?? 'Gemini 처리 중…'}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, width: '100%', maxWidth: 320 }}>
        {PROC_STEPS.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: i < activeIdx ? 'var(--success)' : i === activeIdx ? 'var(--accent-warm)' : 'var(--text-tertiary)', transition: 'color 0.3s' }}>
            <span aria-hidden>{i < activeIdx ? '●' : i === activeIdx ? '◉' : '○'}</span>{s}
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Roadmap Step Card ─────────────────────────────────────────────────────────
function StepCard({ step, index }: { step: RoadmapStep; index: number }) {
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const copyRef = useRef<HTMLButtonElement>(null)

  const copy = () => {
    navigator.clipboard.writeText(step.prompt).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', marginBottom: 10, animationDelay: `${index * 0.07}s`, animation: 'fadeIn 0.5s ease both' }}>
      <button
        aria-expanded={open}
        onClick={() => setOpen(o => !o)}
        style={{ width: '100%', background: 'transparent', border: 'none', padding: '20px 24px', display: 'flex', alignItems: 'flex-start', gap: 16, cursor: 'pointer', textAlign: 'left' }}
      >
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: 'var(--text-tertiary)', minWidth: 28, paddingTop: 2 }}>0{index + 1}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 4 }}>{step.title}</div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{step.description}</div>
          {step.recommended_tools.length > 0 && (
            <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {step.recommended_tools.map(t => (
                <span key={t} style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: 'var(--accent-warm)', border: '1px solid rgba(200,184,154,0.3)', padding: '3px 8px', borderRadius: 2, letterSpacing: '0.1em' }}>{t}</span>
              ))}
            </div>
          )}
        </div>
        <span aria-hidden style={{ color: 'var(--text-tertiary)', fontSize: 12, transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'none', marginTop: 2 }}>▾</span>
      </button>
      <div style={{ maxHeight: open ? 600 : 0, overflow: 'hidden', transition: 'max-height 0.35s ease' }}>
        <div style={{ margin: '0 24px 20px', padding: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', position: 'relative' }}>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: 'var(--text-tertiary)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 10 }}>Copy-Ready Prompt</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: 'var(--accent)', lineHeight: 1.7, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{step.prompt}</div>
          <button
            ref={copyRef}
            onClick={copy}
            aria-label="프롬프트 복사"
            style={{ position: 'absolute', top: 12, right: 12, background: 'var(--bg)', border: `1px solid ${copied ? 'rgba(108,201,126,0.4)' : 'var(--border)'}`, color: copied ? 'var(--success)' : 'var(--text-secondary)', fontFamily: "'JetBrains Mono',monospace", fontSize: 9, padding: '4px 8px', borderRadius: 2, cursor: 'pointer', letterSpacing: '0.1em' }}
          >
            {copied ? 'COPIED ✓' : 'COPY'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Error Solution Display ────────────────────────────────────────────────────
function ErrorDisplay({ message, solution, onRetry }: { message: string; solution: string; onRetry: () => void }) {
  return (
    <div role="alert" style={{ width: '100%', maxWidth: 680, border: '1px solid rgba(224,92,92,0.3)', borderRadius: 'var(--radius-lg)', padding: 28, background: 'rgba(224,92,92,0.04)', animation: 'fadeIn 0.4s ease both' }}>
      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: 'var(--error)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 14 }}>오류 발생</div>
      <div style={{ fontSize: 15, color: 'var(--text-primary)', marginBottom: 10, fontWeight: 500 }}>{message}</div>
      <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 20 }}>{solution}</div>
      <button style={S.btn} onClick={onRetry}>← 다시 시도</button>
    </div>
  )
}

// ─── Error Helper Section ──────────────────────────────────────────────────────
function ErrorHelperSection({ currentGoal }: { currentGoal: string }) {
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [sol, setSol] = useState<{ message: string; solution: string } | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => { if (open) inputRef.current?.focus() }, [open])

  const submit = async () => {
    if (!text.trim()) return
    setLoading(true); setSol(null)
    const res = await fetch('/api/ai-system', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goal: currentGoal, answers: null, error: text }),
    })
    const data: AIResponse = await res.json()
    if (data.type === 'error_solution') setSol({ message: data.message, solution: data.solution })
    setLoading(false)
  }

  return (
    <div style={{ width: '100%', maxWidth: 680, marginTop: 20, border: '1px solid rgba(224,92,92,0.2)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
      <button
        aria-expanded={open}
        onClick={() => setOpen(o => !o)}
        style={{ width: '100%', background: 'rgba(224,92,92,0.04)', border: 'none', padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', textAlign: 'left' }}
      >
        <span style={{ color: 'var(--error)', fontSize: 14 }} aria-hidden>⚠</span>
        <span style={{ fontSize: 13, color: 'var(--text-secondary)', flex: 1 }}>오류가 생겼으면 알려주세요</span>
        <span aria-hidden style={{ color: 'var(--text-tertiary)', fontSize: 11, transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'none' }}>▾</span>
      </button>
      <div style={{ maxHeight: open ? 500 : 0, overflow: 'hidden', transition: 'max-height 0.35s ease' }}>
        <div style={{ padding: '16px 24px 20px', borderTop: '1px solid rgba(224,92,92,0.15)' }}>
          <input
            ref={inputRef}
            style={{ width: '100%', background: 'transparent', border: 'none', borderBottom: '1px solid rgba(224,92,92,0.25)', outline: 'none', color: 'var(--text-primary)', fontFamily: "'Noto Sans KR',sans-serif", fontSize: 14, fontWeight: 300, padding: '8px 0', caretColor: 'var(--error)' }}
            placeholder="어떤 오류가 발생했나요?"
            value={text}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') submit() }}
            aria-label="오류 입력"
          />
          <div style={{ marginTop: 14, display: 'flex', justifyContent: 'flex-end' }}>
            <button
              onClick={submit}
              disabled={loading}
              style={{ background: 'rgba(224,92,92,0.12)', color: 'var(--error)', border: '1px solid rgba(224,92,92,0.25)', fontFamily: "'Noto Sans KR',sans-serif", fontSize: 12, padding: '8px 16px', borderRadius: 'var(--radius)', cursor: 'pointer' }}
            >
              {loading ? '분석 중…' : '오류 분석하기'}
            </button>
          </div>
        </div>
        {sol && (
          <div style={{ margin: '0 24px 20px', padding: 16, background: 'rgba(224,92,92,0.05)', border: '1px solid rgba(224,92,92,0.15)', borderRadius: 'var(--radius)' }}>
            {[{ k: '원인', v: sol.message }, { k: '해결 방법', v: sol.solution }].map(r => (
              <div key={r.k} style={{ marginBottom: 10 }}>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: 'var(--error)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 5 }}>{r.k}</div>
                <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{r.v}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Main Page ─────────────────────────────────────────────────────────────────
export default function Home() {
  const [loaderHidden, setLoaderHidden] = useState(false)
  const [phase, setPhase]               = useState<Phase>('idle')
  const [goal, setGoal]                 = useState('')
  const [questions, setQuestions]       = useState<string[]>([])
  const [roadmapSteps, setRoadmapSteps] = useState<RoadmapStep[]>([])
  const [errorMsg, setErrorMsg]         = useState('')
  const [errorSol, setErrorSol]         = useState('')
  const [procIdx, setProcIdx]           = useState(0)
  const [followUpCount, setFollowUpCount] = useState(0)
  const [answers, setAnswers]           = useState<Record<string, string>>({})
  const goalRef                         = useRef<HTMLTextAreaElement>(null)
  const answerRefs                      = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => { setTimeout(() => setLoaderHidden(true), 2500) }, [])
  useEffect(() => { if (phase === 'idle') goalRef.current?.focus() }, [phase])

  const runProcAnim = () => {
    setProcIdx(0)
    let i = 0
    const iv = setInterval(() => {
      i++
      if (i < PROC_STEPS.length) setProcIdx(i)
      else clearInterval(iv)
    }, 800)
  }

  const callAPI = async (body: object): Promise<AIResponse> => {
    const res = await fetch('/api/ai-system', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    return res.json()
  }

  const handleResponse = (data: AIResponse, currentAnswers: Record<string, string>) => {
    if (data.type === 'form') {
      if (followUpCount >= 1) {
        // force roadmap after 1 follow-up
        setPhase('loading')
        runProcAnim()
        callAPI({ goal, answers: currentAnswers, error: null, forceRoadmap: true }).then(d => handleResponse(d, currentAnswers))
        return
      }
      setFollowUpCount(c => c + 1)
      setQuestions(data.questions)
      answerRefs.current = new Array(data.questions.length).fill(null)
      setPhase('form')
    } else if (data.type === 'roadmap') {
      setRoadmapSteps(data.steps)
      setPhase('roadmap')
    } else if (data.type === 'error_solution') {
      setErrorMsg(data.message)
      setErrorSol(data.solution)
      setPhase('error')
    }
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const submitGoal = async () => {
    if (!goal.trim()) return
    setPhase('loading'); runProcAnim()
    const data = await callAPI({ goal, answers: null, error: null })
    handleResponse(data, {})
  }

  const submitAnswers = async () => {
    const a: Record<string, string> = {}
    let missing = false
    questions.forEach((q, i) => {
      const v = answerRefs.current[i]?.value?.trim() ?? ''
      if (!v) { missing = true; if (answerRefs.current[i]) answerRefs.current[i]!.style.borderBottomColor = 'var(--error)' }
      else { if (answerRefs.current[i]) answerRefs.current[i]!.style.borderBottomColor = '' }
      a[`q${i}`] = v || '(not specified)'
    })
    if (missing) return
    setAnswers(a); setPhase('loading'); runProcAnim()
    const data = await callAPI({ goal, answers: a, error: null })
    handleResponse(data, a)
  }

  const restart = () => {
    setGoal(''); setQuestions([]); setRoadmapSteps([])
    setErrorMsg(''); setErrorSol(''); setFollowUpCount(0); setAnswers({})
    setPhase('idle'); window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <>
      <Loader hidden={loaderHidden} />
      <main style={S.app}>

        {/* Header */}
        <header style={S.header}>
          <div style={S.badge}>
            <span aria-hidden style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--accent-warm)', animation: 'pulse 2s ease-in-out infinite', display: 'inline-block' }} />
            AI Prompt OS · The wAI
          </div>
          <h1 style={S.title}>ai사용이 막막할때<br />ai로 무엇을 하고 싶은지 알려주세요</h1>
        </header>

        {/* Goal card */}
        {(phase === 'idle' || phase === 'form' || phase === 'roadmap' || phase === 'error') && (
          <div style={cs(S.card, { animation: 'fadeIn 0.7s ease 0.25s both' })}>
            <div style={S.cardLabel}>ai 사용 비서</div>
            <textarea
              ref={goalRef}
              style={S.textarea}
              placeholder="Enter your goal or task here…"
              rows={3}
              value={goal}
              onChange={e => setGoal(e.target.value)}
              disabled={phase !== 'idle'}
              aria-label="목표 입력"
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && phase === 'idle') { e.preventDefault(); submitGoal() } }}
            />
            <div style={S.footer}>
              <span style={S.charCount} aria-live="polite">{goal.length}자</span>
              {phase === 'idle'
                ? <button style={S.btn} onClick={submitGoal} aria-label="시작하기">시작하기 →</button>
                : <button style={cs(S.btn, S.btnGhost)} onClick={restart} aria-label="새 목표 입력">← 새 목표</button>
              }
            </div>
          </div>
        )}

        <div style={{ height: 20 }} />

        {/* Loading */}
        {phase === 'loading' && <Processing activeIdx={procIdx} />}

        {/* Form */}
        {phase === 'form' && (
          <div style={{ width: '100%', maxWidth: 680, animation: 'slideUp 0.5s ease both' }}>
            <div style={S.secTitle}>{followUpCount > 1 ? '추가 확인 사항' : '조금 더 알려주세요'}</div>
            <div style={S.secDesc}>{followUpCount > 1 ? '마지막 확인입니다.' : '아래 항목을 작성해 주시면 맞춤 로드맵을 생성합니다.'}</div>
            <div style={S.card}>
              {questions.map((q, i) => (
                <div key={i} style={S.fieldWrap}>
                  <label htmlFor={`q${i}`} style={S.fieldLbl}>{q}</label>
                  <input
                    id={`q${i}`}
                    ref={el => { answerRefs.current[i] = el }}
                    type="text"
                    style={S.fieldIn}
                    placeholder="답변을 입력해 주세요"
                    onKeyDown={e => { if (e.key === 'Enter') submitAnswers() }}
                    aria-required="true"
                  />
                </div>
              ))}
              <div style={cs(S.footer, { paddingTop: 20, borderTop: '1px solid var(--border)', marginTop: 8 })}>
                <button style={cs(S.btn, S.btnGhost)} onClick={restart}>← 처음으로</button>
                <button style={S.btn} onClick={submitAnswers}>로드맵 생성 →</button>
              </div>
            </div>
          </div>
        )}

        {/* Error */}
        {phase === 'error' && <ErrorDisplay message={errorMsg} solution={errorSol} onRetry={restart} />}

        {/* Roadmap */}
        {phase === 'roadmap' && (
          <div style={{ width: '100%', maxWidth: 680, animation: 'slideUp 0.5s ease both' }}>
            <div style={{ marginBottom: 28 }}>
              <div style={S.secTitle}>맞춤 AI 로드맵</div>
              <div style={S.secDesc}>각 단계를 클릭하면 바로 사용 가능한 프롬프트가 나타납니다.</div>
            </div>
            {roadmapSteps.map((s, i) => <StepCard key={i} step={s} index={i} />)}
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 36 }}>
              <button style={cs(S.btn, S.btnGhost)} onClick={restart}>← 새 목표 입력</button>
            </div>
          </div>
        )}

        <div style={{ height: 20 }} />

        {/* Error helper — always visible once goal is entered */}
        {goal && phase !== 'loading' && <ErrorHelperSection currentGoal={goal} />}

      </main>
    </>
  )
}
