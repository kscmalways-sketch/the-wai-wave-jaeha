import { NextRequest, NextResponse } from 'next/server'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface RequestPayload {
  goal: string
  answers: Record<string, string> | null
  error: string | null
  forceRoadmap?: boolean
}

export interface FormResponse {
  type: 'form'
  questions: string[]
}

export interface RoadmapStep {
  step: number
  title: string
  description: string
  prompt: string
  recommended_tools: string[]
}

export interface RoadmapResponse {
  type: 'roadmap'
  steps: RoadmapStep[]
}

export interface ErrorSolutionResponse {
  type: 'error_solution'
  message: string
  solution: string
}

export type AIResponse = FormResponse | RoadmapResponse | ErrorSolutionResponse

// ─── In-memory rate limiter ────────────────────────────────────────────────────
const RATE_WINDOW_MS = 60_000
const RATE_MAX = 20
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()

function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const entry = rateLimitMap.get(ip)
  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS })
    return true
  }
  if (entry.count >= RATE_MAX) return false
  entry.count++
  return true
}

// ─── Logger ────────────────────────────────────────────────────────────────────
function log(level: 'info' | 'warn' | 'error', requestId: string, msg: string, meta?: Record<string, unknown>) {
  const entry = { ts: new Date().toISOString(), level, requestId, path: '/api/ai-system', msg, ...(meta ?? {}) }
  if (level === 'error') console.error(JSON.stringify(entry))
  else if (level === 'warn') console.warn(JSON.stringify(entry))
  else console.log(JSON.stringify(entry))
}

// ─── Prompt builder ────────────────────────────────────────────────────────────
function buildPrompt(payload: RequestPayload): string {
  const lines: string[] = [
    'You are an AI Prompt Operating System decision engine.',
    'Respond ONLY in valid JSON exactly matching one of the three shapes below.',
    'Do NOT include any explanation, markdown, or extra text outside the JSON.',
    '',
    '--- ALLOWED RESPONSE SHAPES ---',
    '',
    'Shape 1 — Form (when more information is needed):',
    '{ "type": "form", "questions": ["Korean question string", ...] }',
    '  Rules: max 5 specific questions in Korean.',
    '',
    'Shape 2 — Roadmap:',
    '{ "type": "roadmap", "steps": [{ "step": 1, "title": "Korean title", "description": "Korean explanation", "prompt": "Complete English prompt, copy-paste ready, no placeholders", "recommended_tools": ["tool names"] }] }',
    '  Rules: 5-7 steps. Each prompt includes all user details. recommended_tools are user-facing suggestions only.',
    '',
    'Shape 3 — Error solution:',
    '{ "type": "error_solution", "message": "Korean: what went wrong", "solution": "Korean: how to fix" }',
    '',
    '--- USER INPUT ---',
    `Goal: ${payload.goal || '(none)'}`,
  ]

  if (payload.answers && Object.keys(payload.answers).length > 0) {
    lines.push('', 'User answers:')
    Object.entries(payload.answers).forEach(([k, v]) => lines.push(`  - ${k}: ${v}`))
  }

  if (payload.error) {
    lines.push(``, `Error reported: ${payload.error}`, '', 'Respond with Shape 3 (error_solution).')
  } else if (payload.forceRoadmap) {
    lines.push('', 'Generate roadmap NOW. Auto-fill missing details. Respond with Shape 2 (roadmap).')
  } else if (payload.answers && Object.keys(payload.answers).length > 0) {
    lines.push('', 'User answered questions. Respond with Shape 2 (roadmap) unless one critical piece is truly missing (then Shape 1 once only).')
  } else {
    lines.push('', 'No answers yet. Respond with Shape 1 (form) or Shape 2 (roadmap) if goal is already specific enough.')
  }

  lines.push('', 'All decisions made by you (Gemini). Respond ONLY with the JSON object.')
  return lines.join('\n')
}

// ─── Custom error ──────────────────────────────────────────────────────────────
class GeminiError extends Error {
  constructor(message: string, public status: number) {
    super(message)
    this.name = 'GeminiError'
  }
}

// ─── Gemini API call ───────────────────────────────────────────────────────────
async function callGemini(prompt: string, requestId: string): Promise<AIResponse> {
  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) throw new GeminiError('GEMINI_API_KEY not set', 500)

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 15_000)

  let res: Response
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Request-Id': requestId },
      signal: controller.signal,
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
      }),
    })
  } catch (err) {
    clearTimeout(timeout)
    if ((err as Error).name === 'AbortError') throw new GeminiError('Request timed out', 504)
    throw new GeminiError(`Network error: ${(err as Error).message}`, 502)
  }
  clearTimeout(timeout)

  if (res.status === 429) throw new GeminiError('Gemini quota exceeded', 429)
  if (!res.ok) {
    const body = await res.text().catch(() => '')
    log('error', requestId, 'Gemini API error', { status: res.status, body: body.slice(0, 200) })
    throw new GeminiError(`Gemini returned ${res.status}`, 502)
  }

  const data = await res.json()
  const rawText: string = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? ''
  return parseGeminiResponse(rawText, requestId)
}

// ─── Robust JSON parser (exported for unit tests) ─────────────────────────────
export function parseGeminiResponse(raw: string, requestId = 'parse'): AIResponse {
  let cleaned = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
  const start = cleaned.indexOf('{')
  const end = cleaned.lastIndexOf('}')

  if (start === -1 || end === -1) {
    log('warn', requestId, 'No JSON found', { raw: raw.slice(0, 300) })
    return { type: 'error_solution', message: 'AI 응답을 파싱할 수 없습니다.', solution: '다시 시도해 주세요.' }
  }
  cleaned = cleaned.slice(start, end + 1)

  let parsed: unknown
  try { parsed = JSON.parse(cleaned) }
  catch {
    log('warn', requestId, 'JSON.parse failed', { cleaned: cleaned.slice(0, 300) })
    return { type: 'error_solution', message: 'AI 응답 파싱 실패.', solution: '다시 시도해 주세요.' }
  }

  if (!parsed || typeof parsed !== 'object') {
    return { type: 'error_solution', message: '예상치 못한 응답 형식.', solution: '다시 시도해 주세요.' }
  }
  const obj = parsed as Record<string, unknown>

  if (obj.type === 'form') {
    const questions = Array.isArray(obj.questions)
      ? (obj.questions as unknown[]).filter((q): q is string => typeof q === 'string')
      : []
    return { type: 'form', questions }
  }

  if (obj.type === 'roadmap') {
    const rawSteps = Array.isArray(obj.steps) ? obj.steps : []
    const steps: RoadmapStep[] = rawSteps.map((s: unknown, i: number) => {
      const st = (s && typeof s === 'object' ? s : {}) as Record<string, unknown>
      return {
        step: typeof st.step === 'number' ? st.step : i + 1,
        title: typeof st.title === 'string' ? st.title : `단계 ${i + 1}`,
        description: typeof st.description === 'string' ? st.description : '',
        prompt: typeof st.prompt === 'string' ? st.prompt : '',
        recommended_tools: Array.isArray(st.recommended_tools)
          ? (st.recommended_tools as unknown[]).filter((t): t is string => typeof t === 'string')
          : [],
      }
    })
    return { type: 'roadmap', steps }
  }

  if (obj.type === 'error_solution') {
    return {
      type: 'error_solution',
      message: typeof obj.message === 'string' ? obj.message : 'AI 오류.',
      solution: typeof obj.solution === 'string' ? obj.solution : '다시 시도해 주세요.',
    }
  }

  log('warn', requestId, 'Unknown type', { type: obj.type })
  return { type: 'error_solution', message: '알 수 없는 응답 형식.', solution: '다시 시도해 주세요.' }
}

// ─── Route handler ─────────────────────────────────────────────────────────────
export async function POST(req: NextRequest): Promise<NextResponse> {
  const requestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown'

  log('info', requestId, 'Incoming request', { ip })

  if (!checkRateLimit(ip)) {
    log('warn', requestId, 'Rate limit exceeded', { ip })
    return NextResponse.json(
      { type: 'error_solution', message: '요청이 너무 많습니다.', solution: '1분 후 다시 시도해 주세요.' } satisfies ErrorSolutionResponse,
      { status: 429 }
    )
  }

  let payload: RequestPayload
  try { payload = await req.json() }
  catch {
    log('warn', requestId, 'Invalid JSON body')
    return NextResponse.json(
      { type: 'error_solution', message: '잘못된 요청 형식.', solution: '페이지를 새로고침 후 다시 시도해 주세요.' } satisfies ErrorSolutionResponse,
      { status: 400 }
    )
  }

  if (typeof payload.goal !== 'string' || !payload.goal.trim()) {
    return NextResponse.json(
      { type: 'error_solution', message: '목표(goal)를 입력해 주세요.', solution: '목표를 입력해 주세요.' } satisfies ErrorSolutionResponse,
      { status: 400 }
    )
  }

  if (!process.env.GEMINI_API_KEY) {
    log('error', requestId, 'GEMINI_API_KEY not configured')
    return NextResponse.json(
      { type: 'error_solution', message: '서버 설정 오류.', solution: '관리자에게 문의해 주세요.' } satisfies ErrorSolutionResponse,
      { status: 500 }
    )
  }

  const prompt = buildPrompt(payload)
  log('info', requestId, 'Calling Gemini', { goalLength: payload.goal.length, hasAnswers: !!payload.answers })

  try {
    const result = await callGemini(prompt, requestId)
    log('info', requestId, 'Success', { type: result.type })
    return NextResponse.json(result, { status: 200 })
  } catch (err) {
    if (err instanceof GeminiError) {
      log('error', requestId, err.message, { status: err.status })
      const statusMap: Record<number, ErrorSolutionResponse> = {
        429: { type: 'error_solution', message: 'Gemini API 사용 한도 초과.', solution: '잠시 후 다시 시도하거나 Gemini API 사용량을 확인해 주세요.' },
        504: { type: 'error_solution', message: 'AI 응답 시간 초과.', solution: '잠시 후 다시 시도해 주세요.' },
      }
      return NextResponse.json(
        statusMap[err.status] ?? { type: 'error_solution', message: 'AI 서비스 오류.', solution: err.message },
        { status: err.status }
      )
    }
    log('error', requestId, 'Unexpected error', { err: String(err) })
    return NextResponse.json(
      { type: 'error_solution', message: '예상치 못한 오류.', solution: '잠시 후 다시 시도해 주세요.' } satisfies ErrorSolutionResponse,
      { status: 500 }
    )
  }
}
