import { parseGeminiResponse } from '../../app/api/ai-system/route'

describe('parseGeminiResponse — form', () => {
  it('parses a valid form response', () => {
    const raw = JSON.stringify({ type: 'form', questions: ['프로젝트 이름은 무엇인가요?', '대상 사용자는 누구인가요?'] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('form')
    if (result.type === 'form') {
      expect(result.questions).toHaveLength(2)
      expect(result.questions[0]).toBe('프로젝트 이름은 무엇인가요?')
    }
  })

  it('strips markdown code fences and parses', () => {
    const raw = '```json\n{ "type": "form", "questions": ["질문1"] }\n```'
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('form')
  })

  it('handles empty questions array', () => {
    const raw = JSON.stringify({ type: 'form', questions: [] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('form')
    if (result.type === 'form') expect(result.questions).toHaveLength(0)
  })

  it('filters non-string questions', () => {
    const raw = JSON.stringify({ type: 'form', questions: ['valid', 42, null, 'also valid'] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('form')
    if (result.type === 'form') expect(result.questions).toEqual(['valid', 'also valid'])
  })
})

describe('parseGeminiResponse — roadmap', () => {
  const sampleStep = { step: 1, title: '기획', description: '기획 단계', prompt: 'Create a plan for...', recommended_tools: ['ChatGPT', 'Notion'] }

  it('parses a valid roadmap response', () => {
    const raw = JSON.stringify({ type: 'roadmap', steps: [sampleStep] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('roadmap')
    if (result.type === 'roadmap') {
      expect(result.steps).toHaveLength(1)
      expect(result.steps[0].title).toBe('기획')
      expect(result.steps[0].recommended_tools).toEqual(['ChatGPT', 'Notion'])
    }
  })

  it('fills defaults for missing fields', () => {
    const raw = JSON.stringify({ type: 'roadmap', steps: [{}] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('roadmap')
    if (result.type === 'roadmap') {
      expect(result.steps[0].step).toBe(1)
      expect(result.steps[0].title).toBe('단계 1')
      expect(result.steps[0].recommended_tools).toEqual([])
    }
  })

  it('handles roadmap with extra text before JSON', () => {
    const raw = 'Sure! Here is the roadmap:\n' + JSON.stringify({ type: 'roadmap', steps: [sampleStep] })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('roadmap')
  })
})

describe('parseGeminiResponse — error_solution', () => {
  it('parses a valid error_solution', () => {
    const raw = JSON.stringify({ type: 'error_solution', message: '오류 발생', solution: '다시 시도해 주세요' })
    const result = parseGeminiResponse(raw)
    expect(result.type).toBe('error_solution')
    if (result.type === 'error_solution') {
      expect(result.message).toBe('오류 발생')
      expect(result.solution).toBe('다시 시도해 주세요')
    }
  })
})

describe('parseGeminiResponse — malformed inputs', () => {
  it('returns error_solution for empty string', () => {
    const result = parseGeminiResponse('')
    expect(result.type).toBe('error_solution')
  })

  it('returns error_solution for invalid JSON', () => {
    const result = parseGeminiResponse('{ this is not json }')
    expect(result.type).toBe('error_solution')
  })

  it('returns error_solution for unknown type', () => {
    const result = parseGeminiResponse(JSON.stringify({ type: 'something_unknown' }))
    expect(result.type).toBe('error_solution')
  })

  it('returns error_solution for plain text', () => {
    const result = parseGeminiResponse('I cannot answer that.')
    expect(result.type).toBe('error_solution')
  })

  it('returns error_solution for deeply nested wrong shape', () => {
    const result = parseGeminiResponse(JSON.stringify({ wrapper: { type: 'form' } }))
    expect(result.type).toBe('error_solution')
  })
})
