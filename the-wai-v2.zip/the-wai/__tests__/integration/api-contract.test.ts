/**
 * Integration-style tests for the POST handler logic.
 * We test the full request→response contract using the exported functions directly,
 * mocking the Gemini network call at the fetch level.
 */

import { parseGeminiResponse } from '../../app/api/ai-system/route'

// ── Mock fetch globally ────────────────────────────────────────────────────────
const mockFetch = jest.fn()
global.fetch = mockFetch

function mockGeminiResponse(text: string, status = 200) {
  mockFetch.mockResolvedValueOnce({
    ok: status >= 200 && status < 300,
    status,
    json: async () => ({
      candidates: [{ content: { parts: [{ text }] } }],
    }),
    text: async () => `Error ${status}`,
  })
}

beforeEach(() => {
  mockFetch.mockClear()
  process.env.GEMINI_API_KEY = 'test-key-mock'
})

// ── Contract: form response ────────────────────────────────────────────────────
describe('API contract — form response', () => {
  it('returns type:form with questions array', () => {
    const raw = JSON.stringify({ type: 'form', questions: ['프로젝트 이름은?', '주요 기능은?'] })
    const parsed = parseGeminiResponse(raw)
    expect(parsed.type).toBe('form')
    if (parsed.type === 'form') {
      expect(Array.isArray(parsed.questions)).toBe(true)
      expect(parsed.questions.length).toBeGreaterThan(0)
    }
  })
})

// ── Contract: roadmap response ─────────────────────────────────────────────────
describe('API contract — roadmap response', () => {
  it('returns type:roadmap with valid steps', () => {
    const raw = JSON.stringify({
      type: 'roadmap',
      steps: [
        { step: 1, title: '기획', description: '프로젝트 기획', prompt: 'Create a project plan for a mobile app...', recommended_tools: ['ChatGPT', 'Notion'] },
        { step: 2, title: '디자인', description: '화면 설계', prompt: 'Design the UI for...', recommended_tools: ['Figma', 'Midjourney'] },
      ],
    })
    const parsed = parseGeminiResponse(raw)
    expect(parsed.type).toBe('roadmap')
    if (parsed.type === 'roadmap') {
      expect(parsed.steps.length).toBe(2)
      expect(parsed.steps[0].prompt.length).toBeGreaterThan(10)
      expect(Array.isArray(parsed.steps[0].recommended_tools)).toBe(true)
    }
  })
})

// ── Contract: error_solution response ─────────────────────────────────────────
describe('API contract — error_solution response', () => {
  it('returns error_solution with message and solution', () => {
    const raw = JSON.stringify({ type: 'error_solution', message: 'API 키가 잘못되었습니다.', solution: 'API 키를 확인해 주세요.' })
    const parsed = parseGeminiResponse(raw)
    expect(parsed.type).toBe('error_solution')
    if (parsed.type === 'error_solution') {
      expect(typeof parsed.message).toBe('string')
      expect(typeof parsed.solution).toBe('string')
    }
  })
})

// ── Malformed response resilience ─────────────────────────────────────────────
describe('API contract — malformed Gemini response', () => {
  const malformedCases = [
    ['empty string', ''],
    ['plain text', 'I cannot help with that.'],
    ['incomplete JSON', '{ "type": "roadmap"'],
    ['wrong shape', JSON.stringify({ data: 'unexpected' })],
    ['markdown wrapped', '```json\n{ bad json }\n```'],
  ]

  malformedCases.forEach(([name, raw]) => {
    it(`handles ${name} → returns error_solution`, () => {
      const result = parseGeminiResponse(raw as string)
      expect(result.type).toBe('error_solution')
    })
  })
})

// ── No secret leaking ──────────────────────────────────────────────────────────
describe('Security: no key exposure', () => {
  it('GEMINI_API_KEY does not appear in parsed response', () => {
    const key = process.env.GEMINI_API_KEY ?? 'test-key-mock'
    const raw = JSON.stringify({ type: 'form', questions: ['질문?'] })
    const result = parseGeminiResponse(raw)
    expect(JSON.stringify(result)).not.toContain(key)
  })
})
